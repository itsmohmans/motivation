## Add-on submission checklist

Please verify the following points before finalizing your submission. This will minimize delays or misunderstanding during the review process:

- Include detailed version notes (this can be done in the next step).
- If your add-on requires an account to a website in order to be fully tested, include a test username and password in the Notes to Reviewer (this can be done in the next step).

The validation process found these issues that can lead to rejections:

- The Function constructor is eval.
  Warning: Evaluation of strings as code can lead to security vulnerabilities and performance issues, even in the most innocuous of circumstances. Please avoid using `eval` and the `Function` constructor when at all possible.

---

## To-DO List

- [x] add a text to indicate that this time is your age

- [x] add options to show/hide quote

- [ ] add option to show / hide specific time units

- [ ] add options to control the time running speed

- [ ] add option to edit birthdate

- [ ] add the ability to add links to the homepage and save them in localStorage

- [ ] add an auto-focused search bar

- [ ] publish it on chrome web store

- [x] research why my contribution on Github do not count, maybe change the branch name to `main`

- [ ] add about section with link to my github

- [ ] add color themes to settings

- [ ] add option to change quote

- [ ] add option to show current date and time