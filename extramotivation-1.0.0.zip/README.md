ExtraMotivation
========
A fork of [Lysak/Motivation](https://github.com/Lysak/motivation) extenstion with all time units instead of just year and fractions for extra ~~anxiety~~ motivation.

<!-- For Chrome add add-on from [chrome.google.com/webstore](https://chrome.google.com/webstore/detail/motivation/aliachjmgkelibfecomdccomahgpople/ "https://chrome.google.com/webstore/detail/motivation/aliachjmgkelibfecomdccomahgpople/")

![](chrome.png) -->

<!-- For Firefox add add-on from [addons.mozilla.org](https://addons.mozilla.org/ru/firefox/addon/motivation-new-tab/ "https://addons.mozilla.org/ru/firefox/addon/motivation-new-tab/") -->

![](firefox.png)
